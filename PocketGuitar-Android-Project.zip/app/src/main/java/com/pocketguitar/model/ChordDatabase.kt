package com.pocketguitar.model

import kotlin.math.pow

data class Chord(
    val name: String,
    val root: String,
    val quality: String,
    val frets: IntArray,
    val fingers: IntArray,
    val barreFret: Int? = null,
    val barreFrom: Int? = null
) {
    fun getFrequencies(capo: Int = 0): FloatArray {
        val openNotes = intArrayOf(40, 45, 50, 55, 59, 64)
        val freqs = FloatArray(6)
        for (i in 0 until 6) {
            val fret = frets[i]
            if (fret < 0) {
                freqs[i] = 0f
            } else {
                val midi = openNotes[i] + fret + capo
                freqs[i] = (440.0 * 2.0.pow((midi - 69) / 12.0)).toFloat()
            }
        }
        return freqs
    }
}

object ChordDatabase {
    val NOTE_NAMES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    val CHORDS: Map<String, Chord> = mapOf(
        "C" to Chord("C", "C", "Major", intArrayOf(-1, 3, 2, 0, 1, 0), intArrayOf(0, 3, 2, 0, 1, 0)),
        "Cm" to Chord("Cm", "C", "Minor", intArrayOf(-1, 3, 5, 5, 4, 3), intArrayOf(0, 1, 3, 4, 2, 1), 3, 1),
        "C7" to Chord("C7", "C", "7", intArrayOf(-1, 3, 2, 3, 1, 0), intArrayOf(0, 3, 2, 4, 1, 0)),
        "Cmaj7" to Chord("Cmaj7", "C", "maj7", intArrayOf(-1, 3, 2, 0, 0, 0), intArrayOf(0, 3, 2, 0, 0, 0)),
        "Cm7" to Chord("Cm7", "C", "m7", intArrayOf(-1, 3, 5, 3, 4, 3), intArrayOf(0, 1, 3, 1, 2, 1), 3, 1),
        "Csus4" to Chord("Csus4", "C", "sus4", intArrayOf(-1, 3, 3, 0, 1, 1), intArrayOf(0, 3, 4, 0, 1, 1)),
        "D" to Chord("D", "D", "Major", intArrayOf(-1, -1, 0, 2, 3, 2), intArrayOf(0, 0, 0, 1, 3, 2)),
        "Dm" to Chord("Dm", "D", "Minor", intArrayOf(-1, -1, 0, 2, 3, 1), intArrayOf(0, 0, 0, 2, 3, 1)),
        "D7" to Chord("D7", "D", "7", intArrayOf(-1, -1, 0, 2, 1, 2), intArrayOf(0, 0, 0, 2, 1, 3)),
        "E" to Chord("E", "E", "Major", intArrayOf(0, 2, 2, 1, 0, 0), intArrayOf(0, 2, 3, 1, 0, 0)),
        "Em" to Chord("Em", "E", "Minor", intArrayOf(0, 2, 2, 0, 0, 0), intArrayOf(0, 2, 3, 0, 0, 0)),
        "F" to Chord("F", "F", "Major", intArrayOf(1, 3, 3, 2, 1, 1), intArrayOf(1, 3, 4, 2, 1, 1), 1, 0),
        "G" to Chord("G", "G", "Major", intArrayOf(3, 2, 0, 0, 3, 3), intArrayOf(2, 1, 0, 0, 3, 4)),
        "A" to Chord("A", "A", "Major", intArrayOf(-1, 0, 2, 2, 2, 0), intArrayOf(0, 0, 1, 2, 3, 0)),
        "Am" to Chord("Am", "A", "Minor", intArrayOf(-1, 0, 2, 2, 1, 0), intArrayOf(0, 0, 2, 3, 1, 0)),
        "Bb" to Chord("Bb", "A#", "Major", intArrayOf(-1, 1, 3, 3, 3, 1), intArrayOf(0, 1, 2, 3, 4, 1), 1, 1),
        "B" to Chord("B", "B", "Major", intArrayOf(-1, 2, 4, 4, 4, 2), intArrayOf(0, 1, 2, 3, 4, 1), 2, 1),
        "Bm" to Chord("Bm", "B", "Minor", intArrayOf(-1, 2, 4, 4, 3, 2), intArrayOf(0, 1, 3, 4, 2, 1), 2, 1)
    )

    fun getChord(name: String): Chord? {
        val trimmed = name.trim()
        return CHORDS[trimmed] ?: CHORDS[trimmed.replaceFirstChar { it.uppercase() }]
    }

    fun getSoundingChordName(name: String, capo: Int): String {
        if (capo == 0) return name
        val chord = getChord(name) ?: return name
        val rootIdx = NOTE_NAMES.indexOf(chord.root)
        if (rootIdx == -1) return name
        val newRoot = NOTE_NAMES[(rootIdx + capo) % 12]
        val suffix = name.removePrefix(chord.root)
        return "$newRoot$suffix"
    }
}