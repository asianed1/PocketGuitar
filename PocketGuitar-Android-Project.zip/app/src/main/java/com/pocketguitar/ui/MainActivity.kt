package com.pocketguitar.ui

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.pocketguitar.audio.AudioEngine
import com.pocketguitar.engine.*
import com.pocketguitar.model.ChordDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

class MainActivity : ComponentActivity() {
    private lateinit var audioEngine: AudioEngine
    private lateinit var strumRunner: StrumLoopRunner
        setContent {
            // Jetpack Compose App Interface
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFF59E0B),
                    surface = Color(0xFF0F172A),
                    background = Color(0xFF020617)
                )
            ) {
                // Adaptive layout: Chords chunked into 2 rows when > 4 chords are selected
                // so buttons maintain generous touch hitboxes and never collapse into thin slivers.
                PocketGuitarApp(audioEngine, strumRunner)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        strumRunner.stop()
        audioEngine.release()
    }
}